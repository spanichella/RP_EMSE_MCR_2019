<img src="http://ofbiz.apache.org/images/logo.png" alt="Apache OFBiz" />

# commonext component
This OFBiz component enables organisations to extend the elements in the common component.

## more information
For more information about this component visit the product page in the OFBiz WIKI, 
which can be found at https://cwiki.apache.org/confluence/display/OFBIZ/Extending+the+common+component

## issues
JIRA issues related to this component can be found at https://issues.apache.org/jira/browse/OFBIZ/component/12313162

## commits
Committed revisions can be viewed at http://svn.apache.org/viewvc/ofbiz/trunk/applications/commonext